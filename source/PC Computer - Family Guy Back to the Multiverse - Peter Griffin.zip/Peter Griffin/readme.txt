Ripped by Hell Inspector under the submitter name "Hawkodile"
https://www.vg-resource.com/user-39500.html

This model was edited into a t-pose, Ninja Ripper didn't rip it in a t-pose.

Credit is appreciated but not needed.

Thank you and Have a great day! Have fun using this model.